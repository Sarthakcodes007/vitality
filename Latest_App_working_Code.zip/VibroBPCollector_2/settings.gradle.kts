pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven { url = uri("https://chaquo.com/maven") } // ✅ Required for Chaquopy
    }
}

dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven(url = "https://jitpack.io") // ✅ Required for MPAndroidChart
    }
}

rootProject.name = "VibroBPCollector_2"
include(":app")
