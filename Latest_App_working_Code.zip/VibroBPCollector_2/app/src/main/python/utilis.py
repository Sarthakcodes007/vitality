import numpy as np
from scipy.signal import hilbert

def envelope_from_acc(signal, fs):
    """
    Computes the envelope of the accelerometer signal using Hilbert transform.

    Args:
        signal (np.array): 1D accelerometer signal.
        fs (int): Sampling frequency.

    Returns:
        np.array: Envelope of the signal.
    """
    analytic_signal = hilbert(signal)
    envelope = np.abs(analytic_signal)
    return envelope
