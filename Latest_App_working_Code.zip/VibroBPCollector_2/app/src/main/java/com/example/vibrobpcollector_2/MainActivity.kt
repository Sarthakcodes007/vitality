package com.example.vibrobpcollector_2

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.*
import android.util.Log
import android.view.Surface
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.utils.ColorTemplate
import java.io.File
import java.io.FileWriter
import java.nio.ByteBuffer

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var analyzeButton: Button
    private lateinit var cameraManager: CameraManager
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private lateinit var backgroundHandler: Handler
    private lateinit var backgroundThread: HandlerThread

    private lateinit var startPPGButton: Button
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var statusTextView: TextView
    private lateinit var ppgChart: LineChart

    private lateinit var sensorManager: SensorManager
    private lateinit var accelerometer: Sensor

    private var isRecording = false
    private lateinit var accelWriter: FileWriter
    private var accelFile: File? = null
    private var lineDataSet = LineDataSet(ArrayList(), "PPG Signal")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Init Python
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }

        startPPGButton = findViewById(R.id.startPPGButton)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        statusTextView = findViewById(R.id.statusTextView)
        ppgChart = findViewById(R.id.ppgChart)
        analyzeButton = findViewById(R.id.analyzeButton)

        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)!!

        backgroundThread = HandlerThread("CameraThread").also {
            it.start()
            backgroundHandler = Handler(it.looper)
        }

        setupChart()

        startPPGButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 101)
            } else {
                togglePPG()
            }
        }

        startButton.setOnClickListener {
            if (!isRecording) {
                val fileName = "accel_data_${System.currentTimeMillis()}.csv"
                accelFile = File(filesDir, fileName)
                accelWriter = FileWriter(accelFile)
                accelWriter.write("timestamp,x,y,z\n")

                isRecording = true
                sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
                statusTextView.text = "Status: Vibro Recording..."
            }
        }

        stopButton.setOnClickListener {
            stopPPG()
            if (isRecording) {
                sensorManager.unregisterListener(this)
                accelWriter.flush()
                accelWriter.close()
                isRecording = false
                statusTextView.text = "Status: Idle"
            }
        }

        analyzeButton.setOnClickListener {
            if (accelFile != null && accelFile!!.exists()) {
                analyzeDataWithPython(accelFile!!.absolutePath)
            } else {
                Toast.makeText(this, "No accel file to analyze", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun analyzeDataWithPython(filePath: String) {
        try {
            val python = Python.getInstance()
            val pyModule = python.getModule("main")
            val result = pyModule.callAttr("analyze_bp", filePath)

            val resultMap = result.toJava(Map::class.java) as Map<String, Double>
            val sbp = resultMap["SBP"]
            val dbp = resultMap["DBP"]
            val map = resultMap["MAP"]

            runOnUiThread {
                statusTextView.text = "SBP: $sbp\nDBP: $dbp\nMAP: $map"
            }
        } catch (e: Exception) {
            runOnUiThread {
                statusTextView.text = "Python error: ${e.message}"
            }
        }
    }

    private fun setupChart() {
        ppgChart.description.isEnabled = false
        ppgChart.setTouchEnabled(false)
        ppgChart.setDrawGridBackground(false)
        ppgChart.setBackgroundColor(android.graphics.Color.WHITE)
        ppgChart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        ppgChart.axisRight.isEnabled = false
        lineDataSet.color = ColorTemplate.getHoloBlue()
        lineDataSet.setDrawValues(false)
        lineDataSet.setDrawCircles(false)
        lineDataSet.lineWidth = 2f
        lineDataSet.mode = LineDataSet.Mode.LINEAR
        ppgChart.data = LineData(lineDataSet)
    }

    private fun togglePPG() {
        if (cameraDevice == null) startPPG() else stopPPG()
    }

    private fun startPPG() {
        try {
            val cameraId = cameraManager.cameraIdList.first {
                val characteristics = cameraManager.getCameraCharacteristics(it)
                characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            }

            imageReader = ImageReader.newInstance(640, 480, ImageFormat.YUV_420_888, 2)
            imageReader?.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage()
                image?.let {
                    val buffer: ByteBuffer = image.planes[0].buffer
                    val data = ByteArray(buffer.remaining())
                    buffer.get(data)

                    var redSum = 0L
                    var count = 0
                    for (i in data.indices step 4) {
                        redSum += data[i].toInt() and 0xFF
                        count++
                    }
                    val avgRed = if (count > 0) redSum / count else 0
                    updatePPGChart(avgRed.toFloat())
                    image.close()
                }
            }, backgroundHandler)

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return

            cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    val surface = imageReader!!.surface
                    camera.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                        override fun onConfigured(session: CameraCaptureSession) {
                            captureSession = session
                            val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                            builder.addTarget(surface)
                            builder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                            session.setRepeatingRequest(builder.build(), null, backgroundHandler)

                            runOnUiThread {
                                statusTextView.text = "Status: Capturing PPG"
                                startPPGButton.text = "Stop PPG"
                            }
                        }

                        override fun onConfigureFailed(session: CameraCaptureSession) {
                            Toast.makeText(this@MainActivity, "Camera config failed", Toast.LENGTH_SHORT).show()
                        }
                    }, backgroundHandler)
                }

                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    cameraDevice = null
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    cameraDevice = null
                    Toast.makeText(this@MainActivity, "Camera error", Toast.LENGTH_SHORT).show()
                }
            }, backgroundHandler)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopPPG() {
        captureSession?.close()
        captureSession = null
        cameraDevice?.close()
        cameraDevice = null
        imageReader?.close()
        imageReader = null
        runOnUiThread {
            startPPGButton.text = "Start PPG"
            statusTextView.text = "Status: Idle"
        }
    }

    private var ppgTimestamp = 0f

    private fun updatePPGChart(ppgValue: Float) {
        ppgTimestamp += 1f
        val entry = Entry(ppgTimestamp, ppgValue)
        lineDataSet.addEntry(entry)
        lineDataSet.notifyDataSetChanged()
        ppgChart.data.notifyDataChanged()
        ppgChart.notifyDataSetChanged()
        ppgChart.invalidate()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (isRecording && event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            val timestamp = System.currentTimeMillis()
            val (x, y, z) = event.values
            accelWriter.write("$timestamp,$x,$y,$z\n")
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startPPG()
        } else {
            Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPPG()
        if (isRecording) {
            sensorManager.unregisterListener(this)
            accelWriter.flush()
            accelWriter.close()
        }
    }
}
